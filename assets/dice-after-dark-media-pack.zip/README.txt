Dice After Dark — Press Media Pack

Developer: Realmono Studio
Website: https://dano-sato.github.io/dice-after-dark-presskit/
Trailer: https://youtu.be/ZIBFn24L7mQ?si=UQgvIszTjG1PnCAM
Press contact: realmonostudio@gmail.com

Contents
- Logo/logo.png — transparent game logo
- Key Art/key-art.png — key art
- Icon/icon.png — game icon
- Screenshots/ — gameplay screenshots

All included assets may be used for editorial coverage of Dice After Dark.
